const {test}=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const {randomBytes}=require('node:crypto');
const {chromium,expect}=require('@playwright/test');
const {Pool}=require('pg');
const fs=require('node:fs');
const path=require('node:path');
test('Laboratorios 6 y 7: panel Next.js, PostgreSQL, MQTT y serial simulado',{skip:process.env.IOT_PANEL_TEST!=='1',timeout:240000},async()=>{
 const uid=randomBytes(4).toString('hex').toUpperCase(),cases=[];
 const evidence=path.resolve('documentacion-iot/laboratorio-7/evidencias');
 const admin=new Pool({host:'127.0.0.1',port:55432,database:'asistencia',user:'iot_owner',password:process.env.POSTGRES_PASSWORD});
 let child,browser,base,log='',manualEvent;
 function pass(id,description){cases.push({id,description,status:'APROBADO',mode:'Servicios reales; serial simulado'})}
 try{
  child=spawn(process.execPath,['documentacion-iot/laboratorio-7/panel-server.cjs','--dev'],{env:{...process.env,SERIAL_SIMULATED:'1',LAB_PORT:'0'},stdio:['ignore','pipe','pipe','ipc'],windowsHide:true});
  child.stderr.on('data',b=>{log+=b});
  await new Promise((resolve,reject)=>{
   const timer=setTimeout(()=>reject(new Error(log||'No inició el panel')),90000);
   child.stdout.on('data',b=>{log+=b;const match=String(b).match(/Panel de laboratorios: (http:\/\/[^\s]+)\/laboratorios/);if(match){base=match[1];clearTimeout(timer);resolve()}});
   child.once('exit',()=>{clearTimeout(timer);reject(new Error(log))});
  });
  assert.equal((await fetch(base+'/api/labs/snapshot')).status,401);pass('P7-01','API de datos exige sesión');
  browser=await chromium.launch({channel:'msedge',headless:true});
  const context=await browser.newContext({viewport:{width:1440,height:1050},timezoneId:'America/Lima'});const page=await context.newPage();
  await page.goto(base+'/laboratorios',{waitUntil:'networkidle',timeout:120000});
  await page.getByLabel('Contraseña del panel').fill(process.env.PANEL_PASSWORD);await page.getByRole('button',{name:'Ingresar',exact:true}).click();
  await expect(page.getByRole('heading',{name:'Un ingreso con asistencia.'})).toBeVisible({timeout:30000});
  await expect(page.getByText('Sistema preparado',{exact:true})).toBeVisible({timeout:20000});pass('P7-02','Sesión y estado del puente en Next.js');
  const forbidden=await context.request.post(base+'/api/labs/readings',{headers:{Origin:'http://otro-equipo.invalid'},data:{uid}});assert.equal(forbidden.status(),403);pass('P7-03','Operaciones rechazan origen distinto al panel local');
  await page.getByLabel('Nombre',{exact:true}).fill('Persona de ensayo del panel');await page.getByLabel('UID de la tarjeta',{exact:true}).fill(uid);
  await page.getByLabel('Solicita asistencia al ingresar').check();await page.getByRole('button',{name:'Guardar tarjeta',exact:true}).click();
  await expect(page.getByText('Tarjeta y permiso guardados.',{exact:true})).toBeVisible();
  const card=(await admin.query('SELECT p.*,c.assistance_requested FROM access_control.permissions p JOIN access_control.cards c USING(uid) WHERE uid=$1',[uid])).rows[0];
  assert.equal(new Date(card.valid_until)-new Date(card.valid_from),10800000);assert.equal(card.assistance_requested,true);pass('P7-04','Formulario crea solicitud de asistencia y permiso de tres horas desde inicio explícito');
  await page.getByLabel('UID para lectura simulada',{exact:true}).fill(uid);await page.getByRole('button',{name:'Simular lectura',exact:true}).click();
  const history=page.getByRole('heading',{name:'Historial de decisiones',exact:true}).locator('..');
  await expect(history.getByRole('row').filter({hasText:uid})).toContainText('Simulado: sin apertura física',{timeout:20000});
  const result=(await admin.query('SELECT result FROM access_control.commands WHERE event_id IN (SELECT event_id FROM access_control.events WHERE uid=$1)',[uid])).rows[0].result;
  assert.equal(result.physical_open,null);pass('P7-05','Lectura desde la web recorre puente, MQTT y validación y vuelve al historial');
  const notice=(await admin.query('SELECT notification_id FROM access_control.notifications WHERE event_id IN (SELECT event_id FROM access_control.events WHERE uid=$1)',[uid])).rows[0];
  await expect(page.locator(`[data-notification-id="${notice.notification_id}"]`)).toBeVisible();
  await page.getByRole('button',{name:'Activar sonido',exact:true}).click();await expect(page.getByRole('button',{name:'Desactivar sonido',exact:true})).toBeVisible();
  pass('P7-06','Aviso visible y control de sonido habilitado; audibilidad física no medida');
  await page.screenshot({path:path.join(evidence,'panel-web-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth));await page.screenshot({path:path.join(evidence,'panel-web-mobile.png'),fullPage:true});pass('P7-07','Vista móvil sin desbordamiento horizontal');
  await page.locator(`[data-notification-id="${notice.notification_id}"]`).getByRole('button',{name:'Confirmar recepción'}).click();
  await expect(page.locator(`[data-notification-id="${notice.notification_id}"]`)).toHaveCount(0);
  assert.equal((await admin.query('SELECT status FROM access_control.notifications WHERE notification_id=$1',[notice.notification_id])).rows[0].status,'acknowledged');pass('P7-08','Confirmación de recepción persiste sin atribuir asistencia realizada');
  await new Promise(resolve=>setTimeout(resolve,3100));
  const manual=await context.request.post(base+'/api/labs/commands',{headers:{Origin:base},data:{relay:2}});assert.equal(manual.status(),202);
  const command=await manual.json();manualEvent=(await admin.query('SELECT event_id FROM access_control.commands WHERE command_id=$1',[command.command_id])).rows[0].event_id;
  await expect.poll(async()=> (await admin.query('SELECT status FROM access_control.commands WHERE command_id=$1',[command.command_id])).rows[0].status).toBe('simulated');pass('P7-09','Orden manual autenticada ABRIR,2 llega al puente simulado');
  const revoke=await context.request.delete(base+`/api/labs/cards/${uid}`,{headers:{Origin:base}});assert.equal(revoke.status(),200);
  assert.equal((await admin.query('SELECT active FROM access_control.cards WHERE uid=$1',[uid])).rows[0].active,false);pass('P7-10','Revocación desde API conserva el historial y deshabilita la credencial');
 }finally{
  if(browser)await browser.close();
  if(child&&child.exitCode===null){const exited=new Promise(resolve=>child.once('exit',resolve));child.send('shutdown');await exited}
  const ids=(await admin.query('SELECT event_id FROM access_control.events WHERE uid=$1',[uid])).rows.map(r=>r.event_id);if(manualEvent)ids.push(manualEvent);
  for(const table of ['notifications','commands','events'])if(ids.length)await admin.query(`DELETE FROM access_control.${table} WHERE event_id=ANY($1::uuid[])`,[ids]);
  await admin.query('DELETE FROM access_control.permissions WHERE uid=$1',[uid]);await admin.query('DELETE FROM access_control.cards WHERE uid=$1',[uid]);await admin.end();
  fs.writeFileSync(path.join(evidence,'panel-verificacion.json'),JSON.stringify({date_local:'2026-10-24',cases,physical_hardware_tested:false,temporary_data_removed:true},null,2)+'\n');
 }
});
