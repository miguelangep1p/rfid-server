'use client';
import {useEffect,useRef,useState} from 'react';
import styles from './panel.module.css';

const localDate=()=>{const d=new Date();return new Date(d.getTime()-d.getTimezoneOffset()*60000).toISOString().slice(0,16)};
const formatDate=value=>value?new Date(value).toLocaleString('es-PE',{timeZone:'America/Lima'}):'Permanente';
async function api(route,body,method=body?'POST':'GET'){
 const response=await fetch(`/api/labs/${route}`,{method,cache:'no-store',headers:body?{'Content-Type':'application/json'}:{},...(body?{body:JSON.stringify(body)}:{})});
 const result=await response.json();if(!response.ok){const error=new Error(result.error);error.status=response.status;throw error}return result;
}
export default function LaboratoryPanel(){
 const [authenticated,setAuthenticated]=useState(null),[password,setPassword]=useState('');
 const [data,setData]=useState(null),[error,setError]=useState(''),[message,setMessage]=useState(''),[busy,setBusy]=useState(false),[sound,setSound]=useState(false),[reading,setReading]=useState('');
 const [form,setForm]=useState({uid:'',name:'',relay:'1',assistance:false,temporary:true,start:localDate()});
 const audio=useRef(null),seen=useRef(null),loading=useRef(false);
 async function refresh(){
  if(loading.current)return;loading.current=true;
  try{
   const value=await api('snapshot');setData(value);
   const ids=value.notifications.map(n=>n.notification_id);
   if(seen.current && ids.some(id=>!seen.current.has(id)) && audio.current?.state==='running'){
    const oscillator=audio.current.createOscillator(),gain=audio.current.createGain();oscillator.connect(gain);gain.connect(audio.current.destination);oscillator.frequency.value=660;gain.gain.value=0.08;oscillator.start();oscillator.stop(audio.current.currentTime+0.18);
   }
   seen.current=new Set(ids);
  }catch(e){if(e.status===401)setAuthenticated(false);else setError(e.message)}finally{loading.current=false}
 }
 useEffect(()=>{api('session').then(r=>setAuthenticated(r.authenticated)).catch(e=>setError(e.message));return()=>{audio.current?.close()}},[]);
 useEffect(()=>{
  if(!authenticated)return;refresh();
  const events=new EventSource('/api/labs/events');events.addEventListener('actualizar',refresh);
  const timer=setInterval(refresh,10000);return()=>{events.close();clearInterval(timer)};
 },[authenticated]);
 async function action(fn,success){setBusy(true);setError('');setMessage('');try{await fn();setMessage(success);if(authenticated)await refresh()}catch(e){setError(e.message)}finally{setBusy(false)}}
 if(!authenticated)return <main className={styles.login}><section className={styles.loginCard}><p className={styles.eyebrow}>UMBRAL · LABORATORIOS 6 Y 7</p><h1>Asistencia en el ingreso</h1><p>Acceso del personal al panel local de tarjetas y avisos.</p><form onSubmit={e=>{e.preventDefault();action(async()=>{await api('session',{password});setPassword('');setAuthenticated(true)},'Sesión iniciada')}}><label>Contraseña del panel<input type="password" autoComplete="current-password" value={password} onChange={e=>setPassword(e.target.value)} required /></label><button disabled={busy||authenticated===null}>{busy?'Ingresando…':'Ingresar'}</button></form>{error&&<p className={styles.error} role="alert">{error}</p>}</section></main>;
 const status=data?.status,pending=data?.notifications.filter(n=>n.status!=='acknowledged')||[];
 return <div className={styles.panel}>
  <header className={styles.header}><a className={styles.logo} href="/laboratorios">u. <span>umbral<small>ASISTENCIA EN EL INGRESO</small></span></a><div className={styles.headerActions}><button className={styles.secondary} onClick={async()=>{try{if(sound){audio.current?.suspend();setSound(false)}else{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)throw new Error('El navegador no admite sonido');audio.current??=new Audio();await audio.current.resume();setSound(true)}}catch(e){setError(e.message)}}}>{sound?'Desactivar sonido':'Activar sonido'}</button><button className={styles.secondary} onClick={()=>action(async()=>{await api('session',null,'DELETE');setAuthenticated(false);setData(null);seen.current=null;audio.current?.suspend();setSound(false)},'')}>Salir</button></div></header>
  <main className={styles.main}>
   <div className={styles.heading}><div><p className={styles.eyebrow}>LABORATORIOS 6 Y 7 · CONTROL Y APOYO</p><h1>Un ingreso con asistencia.</h1><p>Gestiona credenciales y recibe las solicitudes de apoyo en un solo lugar.</p></div><span className={status?.ready?styles.online:styles.offline}>{status?.ready?'Sistema preparado':'Esperando conexión'}</span></div>
   <div className={styles.mode} role="status">{status?.simulated?'Modo de ensayo: las lecturas y las órdenes al relé son simuladas. No se abre ninguna puerta.':'Modo serial real: un comando enviado no confirma la apertura física.'}</div>
   {error&&<div className={styles.error} role="alert">{error}</div>}{message&&<div className={styles.success} role="status">{message}</div>}
   <div className={styles.stats}><section><span>Tarjetas vigentes</span><strong>{data?.cards.filter(c=>c.valid).length||0}</strong></section><section><span>Avisos sin confirmar</span><strong>{pending.length}</strong></section><section><span>Puente serial</span><strong>{status?.serial_connected?'Disponible':'Sin conexión'}</strong></section><section><span>Comunicación MQTT</span><strong>{status?.ready?'Conectada':'Esperando'}</strong></section></div>
   <section className={styles.card} aria-labelledby="avisos-title"><div className={styles.sectionTitle}><div><h2 id="avisos-title">Solicitudes de asistencia</h2><p>Confirmar recepción registra que viste el aviso; no acredita que la asistencia se haya realizado.</p></div><span className={styles.badge}>{pending.length} pendientes</span></div><div className={styles.alerts} aria-live="polite">{!pending.length?<p className={styles.empty}>No hay avisos pendientes.</p>:pending.map(n=><article key={n.notification_id} data-notification-id={n.notification_id} className={styles.alert}><div><strong>Se requiere apoyo en {n.payload.location}</strong><p>{formatDate(n.created_at)} · Acceso {n.payload.decision==='CONCEDIDO'?'autorizado':'denegado'}</p></div><button disabled={busy} onClick={()=>action(()=>api(`notifications/${n.notification_id}/ack`,{}),'Recepción del aviso confirmada.')}>Confirmar recepción</button></article>)}</div></section>
   <div className={styles.twoColumns}>
    <section className={styles.card}><h2>Tarjetas y permisos</h2><p>Los pases temporales duran tres horas desde el inicio elegido.</p><form className={styles.form} onSubmit={e=>{e.preventDefault();action(()=>api('cards',{uid:form.uid,name:form.name,relay:Number(form.relay),assistance_requested:form.assistance,temporary:form.temporary,starts_at:new Date(form.start).toISOString()}),'Tarjeta y permiso guardados.')}}>
     <label>Nombre<input required maxLength={120} value={form.name} onChange={e=>setForm({...form,name:e.target.value})} autoComplete="off" /></label>
     <label>UID de la tarjeta<input required pattern="([a-fA-F0-9]{2}){4,10}" title="UID hexadecimal de entre 4 y 10 bytes" value={form.uid} onChange={e=>setForm({...form,uid:e.target.value.toUpperCase()})} /></label>
     <div className={styles.formRow}><label>Relé<select value={form.relay} onChange={e=>setForm({...form,relay:e.target.value})}><option value="1">Relé 1</option><option value="2">Relé 2</option></select></label><label>Permiso<select value={form.temporary?'temporary':'permanent'} onChange={e=>setForm({...form,temporary:e.target.value==='temporary'})}><option value="temporary">Temporal: 3 horas</option><option value="permanent">Permanente</option></select></label></div>
     <label>Inicio del permiso (hora del equipo)<input required type="datetime-local" value={form.start} onChange={e=>setForm({...form,start:e.target.value})} /></label>
     <label className={styles.checkbox}><input type="checkbox" checked={form.assistance} onChange={e=>setForm({...form,assistance:e.target.checked})} />Solicita asistencia al ingresar</label><p className={styles.small}>Se conserva el historial si renuevas un UID existente. No registres diagnósticos médicos.</p><button disabled={busy}>Guardar tarjeta</button>
    </form></section>
    <section className={styles.card}><h2>Demostrar el flujo de acceso</h2><p>{status?.simulated?'La lectura recorre el puente, MQTT, validación y registro en PostgreSQL.':'Las lecturas llegan desde el Arduino por el puerto serial.'}</p>
     <form className={styles.form} onSubmit={e=>{e.preventDefault();action(()=>api('readings',{uid:reading}),'Lectura de ensayo enviada. Revisa la decisión y el resultado en el historial.')}}><label>UID para lectura simulada<input required pattern="([a-fA-F0-9]{2}){4,10}" value={reading} onChange={e=>setReading(e.target.value.toUpperCase())} /></label><button disabled={busy||!status?.ready||!status?.simulated}>Simular lectura</button></form>
     <h3>Orden manual de acceso</h3><p>El resultado de envío se registra. Los tres segundos son la activación nominal del relé, no la latencia de respuesta.</p><div className={styles.headerActions}>{[1,2].map(relay=><button className={styles.secondary} key={relay} disabled={busy||!status?.ready} onClick={()=>action(()=>api('commands',{relay}),status?.simulated?'Orden manual simulada enviada. No hubo apertura física.':'Comando enviado. La apertura física sigue sin confirmación.')}>{status?.simulated?'Simular apertura':'Enviar apertura'} · Relé {relay}</button>)}</div>
    </section>
   </div>
   <section className={styles.card}><h2>Credenciales registradas</h2><div className={styles.scroll}><table><thead><tr>{['Persona / UID','Relé','Vigencia','Asistencia','Acción'].map(x=><th key={x}>{x}</th>)}</tr></thead><tbody>{data?.cards.map(c=><tr key={c.uid}><td><strong>{c.name}</strong><br/><code>{c.uid}</code></td><td>{c.relay||'—'}</td><td>{!c.active?'Revocada':c.valid?'Vigente':'Fuera de vigencia'}<br/><small>{formatDate(c.valid_until)}</small></td><td>{c.assistance_requested?'Solicitada':'Sin solicitud'}</td><td><button className={styles.secondary} disabled={busy||!c.active} onClick={()=>action(()=>api(`cards/${c.uid}`,null,'DELETE'),'Credencial revocada.')}>Revocar</button></td></tr>)}</tbody></table></div>{!data?.cards.length&&<p className={styles.empty}>Registra una tarjeta para comenzar.</p>}</section>
   <section className={styles.card}><h2>Historial de decisiones</h2><p>Últimos 100 eventos. La autorización y el envío del comando se muestran por separado.</p><div className={styles.scroll}><table><thead><tr>{['Fecha del servidor','Persona / UID','Decisión','Resultado del comando'].map(x=><th key={x}>{x}</th>)}</tr></thead><tbody>{data?.events.map(e=><tr key={e.event_id}><td>{formatDate(e.decided_at)}</td><td>{e.name|| (e.uid==='REMOTO'?'Orden manual':'Desconocido')}<br/><code>{e.uid}</code></td><td>{e.decision==='CONCEDIDO'?'Autorizado':'Denegado'}</td><td>{({simulated:'Simulado: sin apertura física',serial_write_completed:'Escrito al serial: sin confirmación física',mqtt_published:'Publicado en MQTT',pending:'Pendiente',send_failed:'No se confirmó el envío'})[e.command_status]||'Sin orden de apertura'}</td></tr>)}</tbody></table></div>{!data?.events.length&&<p className={styles.empty}>Las lecturas aparecerán aquí.</p>}</section>
   <footer className={styles.footer}>Avisos en pantalla y sonido opcional del navegador. Mensajería externa y asistencia efectiva: por verificar.</footer>
  </main>
 </div>;
}
