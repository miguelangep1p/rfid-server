import './globals.css';

export const metadata = { title: 'Umbral · Control de acceso', description: 'Panel de control RFID' };

export default function Layout({ children }) {
  return <html lang="es"><body>{children}</body></html>;
}
