# Evidencias de laboratorio

Capturas reales del Dashboard y registros de software. No acreditan apertura física ni entrega humana.

- emqx-clients.png: SHA-256 bfe7e2683cc4720b6fad74abc224bb9c93738ae8f3bd3e28f43461190dd0bc26
- emqx-listeners.png: SHA-256 098c4c51b61a153191f2b144d4d2e04baefb478d2f0648e9fe2afded46fc818a
- verificacion-software.json: SHA-256 15ce09d93b345679a331c992587cdf58fcfff1b72a7ac4ac3dd3e1c773f9ad86
