# Evidencias de laboratorio

Capturas reales del Dashboard y registros de software. No acreditan apertura física ni entrega humana.

- emqx-dashboard.png: SHA-256 49c2bedabe87063aea408b73d1c1576b000a721711aa63d2b65b2390b530af8c
- verificacion-software.json: SHA-256 6f0b3c8cc88f166ebd38574ee2e9f0b6e582babc65379c30484c248c939b8461
